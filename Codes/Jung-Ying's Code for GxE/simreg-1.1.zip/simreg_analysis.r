win.size = 5
win.overlap = 4
snp.start = 1
total.snps = 5
run.id = "1"
DIF.TOL = 1e-3
trait.file = "none"
geno.file = "none"
out.dir = "out3"
weight.power = -0.5 # 0 = unweighted, non-zero = (Allele freq ^ x)

source("hsreg.fun.r")
source("hsreg.conversion.r")
source("bwcorefun.G1G2.HSwtbyMAF.r")

##----------------------------------------------------------------------------
## Get the arguments from the command line.
## - config.file is a configuration file describing the run.
if (!exists("config.file"))
{
  args = commandArgs(trailingOnly=TRUE)
  for (a in args)
  {
    nv = strsplit(a,"=",fixed=TRUE)
    name = nv[[1]][1]
    val = nv[[1]][2]
    if (name == "win.size")
      win.size = as.integer(val)
    else if (name == "win.overlap")
      win.overlap = as.integer(val)
    else if (name == "snp.start")
      snp.start = as.integer(val)
    else if (name == "total.snps")
      total.snps = as.integer(val)
    else if (name == "run.id")
      run.id = val
    else if (name == "out.dir")
      out.dir = val
    else if (name == "geno.file")
      geno.file = val
    else if (name == "trait.file")
      trait.file = val
    else if (name == "weight")
      weight.power = as.numeric(val)
    else
      stop(paste("Unexpected parameter name: ", name))
  }
}

if (run.id == "none")
  stop("No run identifier given")

if (trait.file == "none")
  stop("No trait file name given")

if (geno.file == "none")
  stop("No SNPs file name given") 

## Convert impute style genotype data to haplo.score style data.
## This function uses a cutoff to translate dosage values to discrete
## genotype calls.
impute.to.haplo <- function(impute, p.cutoff = 0.8)
{
  ncols = ncol(impute)
  if (ncols %% 3) stop("Impute genotype data must have ncols == 3n.")
  AA = impute[,seq(1, ncols, 3)]
  Aa = impute[,seq(2, ncols, 3)]
  aa = impute[,seq(3, ncols, 3)]

  n.ind = ncol(AA)
  n.snp = nrow(AA)
  haplo = matrix(0, nrow=n.ind, ncol=2*n.snp)
  for (i in 1:n.snp)
  {
    for (j in 1:n.ind)
    {
      a = b = NA
      if (AA[i,j] >= p.cutoff)
      {
        a = 1
        b = 1
      }
      else if (Aa[i,j] >= p.cutoff)
      {
        a = 1
        b = 2
      }
      else if (aa[i,j] >= p.cutoff)
      {
        a = 2
        b = 2
      }    
      haplo[j,(2*i)-1] = a
      haplo[j,2*i] = b 
    }
  } 

  return (haplo)
}

# Trait data is
# Individual Id, BMI, neuroticism score
trait.data = read.table(trait.file, header=F)

ntraits = ncol(trait.data) - 1
if (ntraits < 1)
  stop("Too few columns in trait file.")

yy = trait.data[,2]
xx = trait.data[,3]

xxe = NULL
if (ntraits > 2)
  xxe = trait.data[,3:ntraits + 1]

# CSCS TEMP
# write.table(yy, file="yy.txt") 
# write.table(xx, file="xx.txt") 
# write.table(xxe, file="xxe.txt") 
# stop("Stopped")

# Open the genotypes file - we will read the required lines for each window as we go.
geno.format = "impute"
geno.start.col = 4
gfc = file(geno.file, "r")
tmp = readLines(gfc, n=1) # Skip the header line.

# Open the output files. One each for HSreg, Haplo.glm and single SNP.
snp.fc = file(paste(out.dir, "/simreg_snp.", run.id, ".out", sep=""), "a")
cat(file=snp.fc, "snp.1df.G snp.1df.GxE snp1df.joint snp.2df.G snp.2df.GxE snp.2df.joint\n")

hap.fc = file(paste(out.dir, "/simreg_hap.", run.id, ".out", sep=""), "a")
cat(file=hap.fc, "cutoff hap.G.score hap.GxE.lnlike hapGxE.convg hapG.convg dof\n")

whs.fc = file(paste(out.dir, "/simreg_hs.", run.id, ".out",sep=""), "a")
#cat(file=hs.fc, 
#  "tau","sigma2",
#  "T.GxEm",   "pval.GxEm",   "E.T.GxEm",   "V.T.GxEm",   "aa.GxEm",   "bb.GxEm",
#  "T.G",      "pval.G",      "E.T.G",      "V.T.G",      "aa.G",      "bb.G",
#  "T.joint",  "pval.joint",  "E.T.joint",  "V.T.joint",  "aa.joint",  "bb.joint",
#  "T.jointwt","pval.jointwt","E.T.jointwt","V.T.jointwt","aa.jointwt","bb.jointwt",
#  "\n",
#  sep=" ")
cat(file=whs.fc, "pval.G", "pval.GxEm", "pval.joint", "\n", sep=" ")

# Calculate last SNP to be included.
snp.max = snp.start + total.snps - 1

# If we are not starting at the first SNP we must position the read pointer in the 
# genotypes file to account for this.
# cat("snp.start = ", snp.start, "\n")
if (snp.start > 1)
{
  skip = snp.start - 1
  chunk = 100
  while (skip > chunk) 
  {
    readLines(gfc, n=chunk)
    skip = skip - chunk
  }
  tmp = readLines(gfc, n=skip)
}
tmp = NULL

# Calculate the step size from one window to the next and the total number of windows. 
step.size = win.size - win.overlap
if (step.size <= 0)
  stop("Inconsistent window and overlap sizes")

cat("Weight power =", weight.power, "\n")

n.win = ceiling((total.snps - win.overlap) / step.size)
cat("Total windows =", n.win, "\n")

for (win in 1:n.win)
{
  cat("Window", win, "of", n.win, "\n")

  win.start = snp.start + (step.size * (win - 1))
  win.end = min(win.start + win.size - 1, snp.max)
  this.win.size = win.end - win.start + 1
  cat("win.start = ", win.start, "win.end = ", win.end, "this.win.size = ", this.win.size, "\n")
  
  # Read the impute-style genotype data for this window.
  if ((win == 1) || (win.overlap == 0))
  {
    impute.geno = hsreg.read.geno(gfc, ignore=(geno.start.col-1), nsnps=this.win.size, geno.format=geno.format)
  }
  else
  {
    offset = win.size - win.overlap
    impute.geno = impute.geno[-(1:offset),] # Remove the stuff we are skipping past
    new.size = this.win.size - win.overlap
    if (new.size > 0)
    {
      # cat("Reading new", new.size, "\n")
      new.geno = hsreg.read.geno(gfc, ignore=(geno.start.col-1), nsnps=new.size, geno.format=geno.format)
      impute.geno = rbind(impute.geno, new.geno)
    }
  }    
    
  # Convert genotype data to counts of A alleles.
  geno = hsreg.prepare.geno.data(impute.geno, "impute")
  nsubj = ncol(geno)
  nloci = nrow(geno)
  
  ## Weighted S matrix.
  geno.A = 1 - geno ## geno is already (1 - real.geno.count)
  geno.a = 2 - geno.A
  AFA = rowSums(geno.A) / (2 * nsubj)
  pseudo1 = 0.99999
  AFA[AFA==1] = pseudo1
  AFA[AFA==0] = 1 - pseudo1
  AFa = 1 - AFA # Allele Freq of "a"

  wt.A = AFA ^ weight.power;   
  wt.a = AFa ^ weight.power;
  
  wtgeno.A = sqrt(wt.A) * geno.A
  wtgeno.a = sqrt(wt.a) * geno.a
  SS.wt = ( crossprod(wtgeno.A) + crossprod(wtgeno.a) ) / nloci

  ##----------------------------------------------------------------------------------------------------
  ##   VC analysis
  xx.std = (xx-mean(xx))/sd(xx)

  xxe.std = NULL
  if (!is.null(xxe))
    xxe.std = (xxe - mean(xxe)) / sd(xxe)

  x.adj = cbind(xx.std, xxe.std)

  whs.std  = vctest.qtG.GxE.jointwt.fun(y=yy, geno=geno, x.adj=x.adj, trait.type="gaussian", SSS=SS.wt)
  whs.std.out = whs.std$pval
  cat(file=whs.fc, append=T, win.start, whs.std.out["pval.G"], whs.std.out["pval.GxEm"], whs.std.out["pval.joint"], "\n");

  ##----------------------------------------------------------------------------------------------------
  ##   Use haplo.glm for marginal GxE test and JOINT test
  haplo.geno = impute.to.haplo(impute.geno)
  
  ggeno = setupGeno(haplo.geno, miss.val=NA)
  if (is.null(xxe)) {
    mydat = data.frame(ggeno=ggeno, yy=yy, xx=xx)
  } else {
    mydat = data.frame(ggeno=ggeno, yy=yy, xx=xx, xxe=xxe)
  }

  ## Run haplo.glm for multiple minimum haplotype frequencies.
  cutoffs = c(5/(2*nsubj), 0.01, 0.02)
  for (cutoff in cutoffs)
  {
    hapglmfit.G = NULL
    hapglmfit.GxE = NULL
    if (is.null(xxe))
    {
      convg.G = try(
        hapglmfit.G <- haplo.glm(yy ~ ggeno+xx, family=gaussian, na.action="na.geno.keep", allele.lev=attributes(ggeno)$unique.alleles, 
        miss.val=NA, data=mydat, locus.label=NA, control = haplo.glm.control(keep.rare.haplo=FALSE, haplo.freq.min=cutoff) ),
      silent=T)
  
      convg.GxE = try(
        hapglmfit.GxE <- haplo.glm(yy ~ ggeno+xx+xx*ggeno, family=gaussian, na.action="na.geno.keep",allele.lev=attributes(ggeno)$unique.alleles, 
        miss.val=NA, data=mydat, locus.label=NA, control = haplo.glm.control(keep.rare.haplo=FALSE, haplo.freq.min=cutoff) ),
      silent=F)

    } else {

      convg.G = try(
        hapglmfit.G  <- haplo.glm(yy ~ ggeno+xx+xxe, family=gaussian, na.action="na.geno.keep", allele.lev=attributes(ggeno)$unique.alleles, 
        miss.val=NA, data=mydat, locus.label=NA, control = haplo.glm.control(keep.rare.haplo=FALSE, haplo.freq.min=cutoff) ),
      silent=T)

      convg.GxE = try(
        hapglmfit.GxE <- haplo.glm(yy ~ ggeno+xx+xxe+xx*ggeno, family=gaussian, na.action="na.geno.keep", allele.lev=attributes(ggeno)$unique.alleles, 
        miss.val=NA,data=mydat, locus.label=NA, control = haplo.glm.control(keep.rare.haplo=FALSE, haplo.freq.min=cutoff) ),
      silent=T)

    }

    if (is.null(hapglmfit.G) || is.null(hapglmfit.GxE))
    {
      cat(file=hap.fc, win.start, cutoff, 1, 1, FALSE, FALSE, 999, "\n")
    } else {

      hapG.convg  = hapglmfit.G$converge.em 
      hapGxE.convg = hapglmfit.GxE$converge.em

      ## --- marginal GxE test using "lnlike" ----
      LRT.GxE = (-2) * (hapglmfit.G$lnlike - hapglmfit.GxE$lnlike )
      ddf = length(hapglmfit.GxE$coef) - length(hapglmfit.G$coef)
      hap.GxE.lnlike = pchisq(LRT.GxE, ddf, lower.tail=F)

      ## ---- marginal G test using "haplo.score" ----
      hap.reg = haplo.score(yy, geno=haplo.geno,x.adj=cbind(xx,xxe), trait.type="gaussian", miss.val=NA, skip.haplo=cutoff)
      hap.G.score = hap.reg$score.global.p
      hap.dof = hap.reg$df

      cat(file=hap.fc, win.start, cutoff, hap.G.score, hap.GxE.lnlike, hapGxE.convg, hapG.convg, hap.dof, "\n")
    }
  }

  ##------------------------------------------------------------
  ## Single SNP analysis
  ## Run for each SNP unique to this window.
#  num.unique = this.win.size - win.overlap
#  min.G = 1
#  min.GxE = 1
#  min.joint = 1
#  for (snp in 1:num.unique)
#  {
#    hapstat.geno = haplo.geno[,(2*snp)-1] + haplo.geno[,2*snp]
#    out = snp.pval.xxGE.xxE.fun(hapstat.geno, Y=yy, xxxGE=xx, xxxE=xxe, family="gaussian")
#    min.G = min(min.G, out[1])
#    min.GxE = min(min.G, out[2])
#    min.joint = min(min.G, out[3])
#  }
#  cat(file=snp.fc, win.start, min.G, min.GxE, min.joint, "\n")

  num.unique = this.win.size - win.overlap
  for (snp in 1:num.unique)
  {
    hapstat.geno = haplo.geno[,(2*snp)-1] + haplo.geno[,2*snp]
    out = snp.pval.xxGE.xxE.fun(hapstat.geno, Y=yy, xxxGE=xx, xxxE=xxe, family="gaussian")
    cat(file=snp.fc, win.start+snp-1, out, "\n")
  }
}
