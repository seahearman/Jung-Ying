#---------------------------------------------------------------------------
# This is a wrapper for calling simreg.analysis (in simreg.fun.r) 
# after loading the contents of a configuration file. Simreg.analysis 
# can also be called by just setting up a config object in code 
# (i.e. not reading it from a file).
#
# Authors: Chris Smith, Bioinformatics Research Center, NCSU
#          Dr. Jung-Ying Tzeng, Bioinformatics Research Center, NCSU
#
# August 2011.
#---------------------------------------------------------------------------

library(MASS)
library(simreg)

# Print the banner
simreg.banner()

# Set up default values for command line arguments.
config.file = NULL
snp.start = NULL
snp.total = NULL
run.id = NULL
chromosome.id = NULL
region.id = NULL

#---------------------------------------------------------------------------
# Get the arguments from the command line.
#
# We allow the caller to override some of the configuration options. This
# makes it easier to call the code to analyze different chunks of a
# genotype data file for a whole chromosome (as one might do on a compute
# cluster).
# 
args = commandArgs(trailingOnly=TRUE)
for (a in args)
{
  nv = strsplit(a,"=",fixed=TRUE)
  name = nv[[1]][1]
  val = nv[[1]][2]
  if (name == "config.file")
    config.file = val
  else if (name == "run.id")
    run.id = val
  else if (name == "chromosome.id")
    chromosome.id = val
  else if (name == "region.id")
    region.id = val
  else if (name == "snp.start")
    snp.start = as.numeric(val) 
  else if (name == "snp.total")
    snp.total = as.numeric(val) 
  else
    stop("Unexpected parameter name: ", name)
}

# We require a configuration file. 
#CSCS Should we allow everything to be specified on the command line?
if (is.null(config.file)) stop("Configuration file name not specified.")
if (!exists("config.file")) stop("Configuration file ", config.file, " not found.")

# Load the configuration parameters.
config = simreg.read.config(config.file)

# Override any configuration values specified on the command line.
if (!is.null(run.id)) config$run.id = run.id
if (!is.null(snp.start)) config$snp.start = snp.start
if (!is.null(snp.total)) config$snp.total = snp.total

# Allow the command line arguments to specify a chromosome identifier.
# This is used to replace a marker in the genotype data file name. This
# lets one config file be used for all chromosomes and regions being 
# analyzed.
if (!is.null(chromosome.id))
{
  cat("Chromosome", chromosome.id, "specified on the command line.\n")
  config$chromosome.id = chromosome.id
  new.geno.file = gsub("@chr_id@", chromosome.id, config$geno.file)
  if (new.geno.file != config$geno.file)
  {
    cat("Replaced chromosome id marker to get geno.file = ", new.geno.file, "\n")
    config$geno.file = new.geno.file
  }
}

# The user can specify a name for this region on the command line. 
if (!is.null(region.id))
{
  cat("Region set to", region.id, "\n")
  config$region.id = region.id
}

#---------------------------------------------------------------------------
# Run the analysis.
#
simreg.result = NULL
simreg.try = try( simreg.result <- simreg.analysis(config, banner=FALSE) )

if (is.null(simreg.result))
  cat("Simreg analysis failed\n")
