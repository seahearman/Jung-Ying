#=====================================================================
# SIMreg Example 1
#=====================================================================

# Load the SIMreg code
library(simreg)

# Get the path to the data files for the example.
path = system.file("extdata", package="simreg")

gtypes = paste(path, "/", "chr16.study.gtypes", sep="")
traits = paste(path, "/", "trait_1_q.txt", sep="")

# Create the configuration object.
config = simreg.config()
config$run.id = "ex1"
config$chromosome.id = 16
config$geno.file = gtypes
config$geno.format = "impute"
config$geno.start.col = 6
config$geno.header = 0
config$trait.file = traits
config$trait.header = 1
config$trait.type = "gaussian"
config$win.size = 10
config$win.overlap = 0
config$weight.power = 1
config$use.covs = 1
config$snp.start = 1
config$snp.total = 233
config$tests = "G"
config$out.dir = "."

# Run SIMreg
simreg.analysis(config)

# Plot the results

# 2-moment p-value only. This plot should exactly match the 
# results from hsreg_example_1.
simreg.manhattan.plot(".", c("pval.G.2m"), fpat="simreg.ex1.out")

